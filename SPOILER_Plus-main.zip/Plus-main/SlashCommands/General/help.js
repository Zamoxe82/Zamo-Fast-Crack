const { MessageEmbed } = require("discord.js")
const { color } = require("../../config.js");

module.exports = {
  name:`help`,
  description: 'get help commands of this bot',
  type: 'CHAT_INPUT',
  botperms:["EMBED_LINKS"],
  cooldown:10,
  run:async(client, interaction,args) => {
  
    let embed = new MessageEmbed()              
    .setAuthor({ name: client.user.username })
    .setColor(color)
    .addField("Moderation:", `\`active, activeconfig, autoline, autoreaction, autoreply, autorole, lock, hide, greet, clear, kick, unhide, unban, timeout, role, mute, move, unlock, unmute, untimeout, vkick, welcomeconfig\``)
    .addField("Actions:", `\`capitals, cutTweet, fast, fkk, letters, math, numbers, plural, points, reverse, top\``)
    .addField("General:", `\`help, ping, bot, bots, invite, avatar, banner,  roles, server, user, tax\``)
    .setFooter({ text: "Requester " + interaction.user.tag,iconURL:interaction.user.displayAvatarURL({ dynamic: true }) })
    interaction.reply({ embeds: [embed] }).catch(err => 0)
  }
}
