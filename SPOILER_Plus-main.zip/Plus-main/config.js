module.exports = {
  token:'MTAwMzk5MjMwNTcwNDg5ODYzMQ.Gyd1wa.Q9PRPxPVr6ThNhRxEBL8KegE9LNV9-7QdTjaLI',
  color:'#303136',
  globalBot:true, // false => if bot is private bot - true => if bot isn't private bot
  guildID:"Server ID",
}
