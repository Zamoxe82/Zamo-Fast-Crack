module.exports = {
	name: 'guildCreate',
  run:async(client, guild)=> {
   client.channels.cache.get("1005125761927225344").send(`Joined: ${guild.name}`)
  }
}
