Full system slash commands: matheros edition
